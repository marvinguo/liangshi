// Main.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

inline std::string GetName(int i)
{
	std::ostringstream outs;
	outs << "Name-" << i;
	return outs.str();
}

inline std::string GetAddress(int i)
{
	std::ostringstream outs;
	outs << "This-Is-Address-" << i;
	return outs.str();
}

int _tmain(int argc, _TCHAR* argv[])
{
	using namespace std;

	sql::mysql::MySQL_Driver *driver = 0;
	auto_ptr<sql::Connection> conn;


	// ---------- �������ݿ����� ---------- 
	try
	{
		driver = sql::mysql::get_mysql_driver_instance();
		conn.reset(driver->connect("tcp://127.0.0.1:3306", "root", "000000"));
		cout << boolalpha << "����״̬: " << !conn->isClosed() << endl;
	}
	catch (sql::SQLException &ex)
	{
		cerr << "Error: " << ex.what() << endl;
	}


	//// ---------- �������� ---------- 
	//driver = sql::mysql::get_mysql_driver_instance();
	//conn.reset(driver->connect("tcp://127.0.0.1:3306/MySqlDemo", "root", "000000"));
	//assert(!conn->isClosed());

	//conn->setAutoCommit(0);	// �ֶ��ύ����
	//auto_ptr<sql::PreparedStatement> prepStat(conn->prepareStatement("INSERT INTO `Person` (`Name`, `Address`, `Age`) VALUES (?, ?, ?)"));
	//try
	//{
	//	for (int i = 0; i < 1000; ++i)
	//	{
	//		prepStat->setString(1, GetName(i));
	//		prepStat->setString(2, GetAddress(i));
	//		prepStat->setInt(3, i % 60 + 20);
	//		prepStat->executeUpdate();
	//	}
	//	conn->commit();
	//	cout << "Info: ���ӳɹ�" << endl;
	//}
	//catch (sql::SQLException &ex)
	//{
	//	conn->rollback();
	//	cerr << "Error: " << ex.what() << endl;
	//}


	//// ---------- ��ȡ���� ---------- 
	//driver = sql::mysql::get_mysql_driver_instance();
	//conn.reset(driver->connect("tcp://127.0.0.1:3306/MySqlDemo", "root", "000000"));
	//assert(!conn->isClosed());
	//auto_ptr<sql::Statement> stat(conn->createStatement());
	//auto_ptr<sql::ResultSet> ret(stat->executeQuery("SELECT * FROM `Person`"));
	//while (ret->next())
	//{
	//	cout << "ID: " << ret->getInt("ID") << " Name: " << ret->getString("Name") << " Address: " << ret->getString("Address") << " Age: " << ret->getInt("Age") << endl;
	//}


	//// ---------- �������� ---------- 
	//driver = sql::mysql::get_mysql_driver_instance();
	//conn.reset(driver->connect("tcp://127.0.0.1:3306/MySqlDemo", "root", "000000"));
	//assert(!conn->isClosed());

	//conn->setAutoCommit(0);	// �ֶ��ύ����
	//auto_ptr<sql::PreparedStatement> prepStat(conn->prepareStatement("UPDATE `Person` SET `Age`=? WHERE `ID`=?"));

	//auto_ptr<sql::Statement> stat(conn->createStatement());
	//auto_ptr<sql::ResultSet> ret(stat->executeQuery("SELECT * FROM `Person`"));
	//try
	//{
	//	while (ret->next())
	//	{
	//		int id = ret->getInt("ID");
	//		int age = ret->getInt("Age");
	//		age += 10;
	//		prepStat->setInt(1, age);
	//		prepStat->setInt(2, id);
	//		prepStat->executeUpdate();
	//	}
	//	conn->commit();
	//	cout << "Info: ���³ɹ�" << endl;
	//}
	//catch (sql::SQLException &ex)
	//{
	//	conn->rollback();
	//	cerr << "Error: " << ex.what() << endl;
	//}


	return 0;
}

