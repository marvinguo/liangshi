MySQL C++ Api Wrapper
=====================

This is a simple MySQL C API Wrapper written on C++

## ToDo

* Add prepeared statements.